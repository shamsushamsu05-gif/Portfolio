import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: ["./src/**/*.{ts,tsx,mdx}"],
  theme: {
    extend: {
      fontFamily: {
        sans: ["var(--font-sans)", "ui-sans-serif", "system-ui", "sans-serif"],
        serif: ["var(--font-serif)", "ui-serif", "Georgia", "serif"],
      },
      colors: {
        /* Deep navy "ledger ink" — the trust anchor of the palette */
        ink: {
          50: "#F3F5F8",
          100: "#E3E8EF",
          200: "#C6CFDD",
          300: "#9CAABF",
          400: "#6B7D97",
          500: "#4A5C76",
          600: "#33445C",
          700: "#223148",
          800: "#152036",
          900: "#0C1626",
          950: "#070D18",
        },
        /* Muted brass accent — audit seals, statements, signatures */
        brass: {
          100: "#F7EFDC",
          200: "#EBD9AF",
          300: "#DCBF7C",
          400: "#CBA556",
          500: "#B2873B",
          600: "#8F6A2C",
          700: "#6D5022",
        },
        paper: {
          DEFAULT: "#FAF9F6",
          tint: "#F2F0EA",
        },
      },
      maxWidth: {
        content: "72rem",
      },
      boxShadow: {
        card: "0 1px 2px rgba(12, 22, 38, 0.04), 0 8px 24px -12px rgba(12, 22, 38, 0.12)",
        "card-hover":
          "0 1px 2px rgba(12, 22, 38, 0.05), 0 18px 40px -16px rgba(12, 22, 38, 0.22)",
      },
      transitionTimingFunction: {
        subtle: "cubic-bezier(0.22, 1, 0.36, 1)",
      },
      keyframes: {
        "fade-up": {
          from: { opacity: "0", transform: "translateY(14px)" },
          to: { opacity: "1", transform: "translateY(0)" },
        },
      },
      animation: {
        "fade-up": "fade-up 0.7s cubic-bezier(0.22, 1, 0.36, 1) both",
      },
    },
  },
  plugins: [],
};

export default config;
