# Shamsudheen Kalayath — Portfolio

A single-page professional portfolio for **Shamsudheen Kalayath**, a Finance, Audit &
Business Advisory professional based in Jizan, Saudi Arabia.

The site is built for recruiters and hiring managers in finance and advisory: it opens with
the positioning statement and the four headline figures, then moves through selected
engagements, a full experience timeline, grouped expertise, credentials and contact details.

**Design direction.** Deliberately restrained rather than "tech portfolio" — a serif
display face (Source Serif 4) against a clean UI sans (Inter), a deep navy "ledger ink"
palette with a muted brass accent, a faint ledger-grid backdrop in the hero, and
scroll-reveal animations subtle enough to read as polish rather than decoration. Light and
dark mode are both first-class.

---

## Tech stack

| Layer | Choice |
| --- | --- |
| Framework | Next.js 14 (App Router) |
| Language | TypeScript (strict) |
| Styling | Tailwind CSS 3 (class-based dark mode) |
| Fonts | `next/font/google` — Inter + Source Serif 4 |
| Icons | Hand-rolled inline SVG (`src/lib/icons.tsx`) |
| Animation | CSS transitions + a small `IntersectionObserver` hook |

No UI kit, no animation library, no API keys, no environment variables.

---

## Local installation

Requires **Node.js 18.17 or newer**.

```bash
npm install
npm run dev
```

Open <http://localhost:3000>.

Other scripts:

```bash
npm run build   # production build
npm run start   # serve the production build
npm run lint    # eslint (next/core-web-vitals)
```

---

## Project structure

```
shamsudheen-kalayath-portfolio/
├── public/
│   ├── favicon.svg
│   └── resume/                     # drop the CV PDF here
├── src/
│   ├── app/
│   │   ├── globals.css             # Tailwind layers + base/component styles
│   │   ├── layout.tsx              # fonts, metadata, no-flash theme script, header/footer
│   │   ├── page.tsx                # section order
│   │   └── robots.ts
│   ├── components/
│   │   ├── layout/
│   │   │   ├── Header.tsx          # sticky nav, active-section highlight, mobile menu
│   │   │   ├── Footer.tsx
│   │   │   └── ThemeToggle.tsx     # light/dark, persisted to localStorage
│   │   ├── sections/
│   │   │   ├── Hero.tsx            # name, title, positioning, CTAs, headline figures
│   │   │   ├── About.tsx
│   │   │   ├── Work.tsx            # selected engagements
│   │   │   ├── Experience.tsx      # timeline
│   │   │   ├── Expertise.tsx       # grouped skills
│   │   │   ├── Credentials.tsx     # qualifications, education, certifications
│   │   │   └── Contact.tsx
│   │   └── ui/
│   │       ├── Card.tsx
│   │       ├── Container.tsx
│   │       ├── Reveal.tsx          # scroll-reveal wrapper
│   │       ├── Section.tsx         # section shell: label, heading, intro
│   │       └── Tag.tsx
│   ├── content/
│   │   └── profile.ts              # ← ALL site content lives here
│   ├── hooks/
│   │   └── useActiveSection.ts
│   └── lib/
│       └── icons.tsx
├── tailwind.config.ts
├── next.config.mjs
├── postcss.config.mjs
└── tsconfig.json
```

---

## Customizing the content

**Everything on the page comes from one file: [`src/content/profile.ts`](src/content/profile.ts).**
No component needs editing to change the text.

| Export | Controls |
| --- | --- |
| `profile` | Name, role, headline, positioning line, location, email, phone, LinkedIn, CV link, availability chips |
| `metrics` | The four headline figures under the hero |
| `about` | About paragraphs and the "currently pursuing" note |
| `engagements` | Selected Work cards — situation / approach / contribution / outcome / skills |
| `experience` | Experience timeline entries and their bullet points |
| `expertise` | Skill groups and their items |
| `qualifications`, `education`, `certifications` | Credentials section |
| `languages` | Languages list in the About section |
| `navItems` | Header navigation — the `href` values must match section `id`s |

### Common edits

**Enable the CV download button.** Save the PDF as
`public/resume/shamsudheen-kalayath-cv.pdf`. To hide the button instead, set
`resumeUrl: null` in `profile`.

**Add or remove an engagement card.** Add or delete an object in the `engagements` array.
Each needs a unique `id`; the grid reflows on its own.

**Reorder or remove a section.** Edit the JSX order in `src/app/page.tsx`, then update
`navItems` in `profile.ts` to match.

**Change the palette.** Edit the `ink`, `brass` and `paper` scales in
[`tailwind.config.ts`](tailwind.config.ts). `ink` is the primary/text colour, `brass` is the
accent, `paper` is the light-mode background. Also update the `themeColor` values in
`src/app/layout.tsx` so the mobile browser chrome matches.

**Change the fonts.** Swap the `Inter` / `Source_Serif_4` imports in
`src/app/layout.tsx` for any other `next/font/google` family — they are wired to the
`--font-sans` and `--font-serif` CSS variables that Tailwind reads, so nothing else needs
touching.

**Adjust the animation.** `src/components/ui/Reveal.tsx` holds the scroll-reveal logic;
pass a `delay` (ms) to stagger items. All motion is already disabled automatically for
visitors with `prefers-reduced-motion`.

---

## Accessibility and SEO notes

- Semantic landmarks, a skip-to-content link, and visible focus rings on every control.
- Dark mode is applied before first paint by an inline script, so there is no flash.
- All motion respects `prefers-reduced-motion`.
- Page metadata (title, description, keywords, Open Graph) is generated from `profile.ts`.
- To add a canonical URL and sitemap after deploying, set `metadataBase` in
  `src/app/layout.tsx`.

## Deployment

Any Next.js host works with no extra configuration. On Vercel: import the repository and
accept the defaults — no environment variables are required.

---

## Content provenance

Every claim, figure and date on this site is taken from Shamsudheen Kalayath's CV and
LinkedIn profile. No metrics, outcomes, testimonials or technologies have been invented or
inferred. Where the source documents state an achievement without a number, it is presented
without one. Identity-document numbers from the CV are deliberately **not** published —
only the "Iqama transferable" status, which is what employers in the Kingdom need to know.
