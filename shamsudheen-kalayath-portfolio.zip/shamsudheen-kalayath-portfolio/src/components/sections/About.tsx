import { Section } from "@/components/ui/Section";
import { Reveal } from "@/components/ui/Reveal";
import { about, languages } from "@/content/profile";

export function About() {
  return (
    <Section
      id="about"
      label="About"
      title="Compliance, accounts and audit — under one point of accountability"
      tinted
    >
      <div className="grid gap-12 lg:grid-cols-12">
        <div className="lg:col-span-7">
          <Reveal>
            <div className="space-y-5 text-base leading-relaxed text-ink-700 dark:text-ink-300">
              {about.paragraphs.map((paragraph) => (
                <p key={paragraph.slice(0, 40)}>{paragraph}</p>
              ))}
            </div>
            <p className="mt-6 inline-flex rounded-md border-l-2 border-brass-500 bg-brass-100/50 px-4 py-2.5 text-sm font-medium text-ink-800 dark:border-brass-400 dark:bg-brass-400/10 dark:text-brass-100">
              {about.pursuing}
            </p>
          </Reveal>
        </div>

        <div className="lg:col-span-5 lg:pl-6">
          <Reveal delay={120}>
            <h3 className="text-xs font-semibold uppercase tracking-[0.18em] text-ink-500 dark:text-ink-400">
              Languages
            </h3>
            <ul className="mt-5 divide-y divide-ink-900/8 dark:divide-ink-100/10">
              {languages.map((language) => (
                <li
                  key={language.name}
                  className="flex items-baseline justify-between gap-4 py-3"
                >
                  <span className="font-medium text-ink-800 dark:text-ink-100">
                    {language.name}
                  </span>
                  <span className="text-sm text-ink-500 dark:text-ink-400">
                    {language.level}
                  </span>
                </li>
              ))}
            </ul>
          </Reveal>
        </div>
      </div>
    </Section>
  );
}
