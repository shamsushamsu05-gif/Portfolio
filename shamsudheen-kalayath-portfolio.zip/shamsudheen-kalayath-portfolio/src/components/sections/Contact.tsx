import { Container } from "@/components/ui/Container";
import { Reveal } from "@/components/ui/Reveal";
import { profile } from "@/content/profile";
import {
  ArrowRightIcon,
  LinkedInIcon,
  MailIcon,
  PhoneIcon,
  PinIcon,
} from "@/lib/icons";

const channels = [
  {
    label: "Email",
    value: profile.email,
    href: `mailto:${profile.email}`,
    Icon: MailIcon,
    external: false,
  },
  {
    label: "Phone",
    value: profile.phone,
    href: `tel:${profile.phoneHref}`,
    Icon: PhoneIcon,
    external: false,
  },
  {
    label: "LinkedIn",
    value: profile.linkedinLabel,
    href: profile.linkedin,
    Icon: LinkedInIcon,
    external: true,
  },
  {
    label: "Location",
    value: profile.location,
    href: null,
    Icon: PinIcon,
    external: false,
  },
] as const;

export function Contact() {
  return (
    <section
      id="contact"
      className="scroll-mt-24 border-t border-ink-900/8 bg-ink-900 py-20 text-paper sm:py-28 dark:border-ink-100/10 dark:bg-ink-900/60"
    >
      <Container>
        <div className="grid gap-12 lg:grid-cols-12 lg:gap-16">
          <div className="lg:col-span-5">
            <Reveal>
              <p className="flex items-center gap-3 text-xs font-semibold uppercase tracking-[0.18em] text-brass-300 before:block before:h-px before:w-8 before:shrink-0 before:bg-brass-400/60 before:content-['']">
                Contact
              </p>
              <h2 className="mt-5 font-serif text-3xl leading-tight tracking-tight sm:text-4xl">
                Open to finance, audit and advisory roles in the Kingdom
              </h2>
              <p className="mt-5 text-base leading-relaxed text-ink-200">
                Iqama transferable and a valid Saudi driving licence — available for roles
                across KSA. The fastest route is email; happy to talk through a portfolio,
                a compliance position or a ZATCA matter directly.
              </p>
              <a
                href={`mailto:${profile.email}`}
                className="group mt-9 inline-flex items-center gap-2 rounded-full bg-brass-400 px-5 py-3 text-sm font-medium text-ink-950 transition-colors duration-200 hover:bg-brass-300"
              >
                Email {profile.shortName}
                <ArrowRightIcon className="h-4 w-4 transition-transform duration-300 ease-subtle group-hover:translate-x-0.5" />
              </a>
            </Reveal>
          </div>

          <div className="lg:col-span-7 lg:pl-8">
            <Reveal delay={120}>
              <dl className="divide-y divide-paper/12">
                {channels.map(({ label, value, href, Icon, external }) => {
                  return (
                    <div
                      key={label}
                      className="flex flex-wrap items-center justify-between gap-x-6 gap-y-2 py-5"
                    >
                      <dt className="flex items-center gap-3 text-sm text-ink-300">
                        <Icon className="h-4 w-4 text-brass-300" />
                        {label}
                      </dt>
                      <dd className="text-base">
                        {href ? (
                          <a
                            href={href}
                            {...(external
                              ? { target: "_blank", rel: "noopener noreferrer" }
                              : {})}
                            className="link-underline break-all text-paper hover:text-brass-300"
                          >
                            {value}
                          </a>
                        ) : (
                          <span className="text-paper">{value}</span>
                        )}
                      </dd>
                    </div>
                  );
                })}
              </dl>
            </Reveal>
          </div>
        </div>
      </Container>
    </section>
  );
}
