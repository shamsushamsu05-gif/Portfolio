import { Card } from "@/components/ui/Card";
import { Reveal } from "@/components/ui/Reveal";
import { Section } from "@/components/ui/Section";
import { expertise } from "@/content/profile";

export function Expertise() {
  return (
    <Section
      id="expertise"
      label="Expertise"
      title="Where the depth is"
      intro="Grouped by the way the work actually divides — reporting, assurance, tax, advisory, operations and the systems underneath."
    >
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {expertise.map((group, index) => (
          <Reveal key={group.group} delay={index * 70}>
            <Card interactive className="h-full p-6 sm:p-7">
              <h3 className="font-serif text-lg text-ink-900 dark:text-paper">
                {group.group}
              </h3>
              <div
                aria-hidden
                className="mt-3 h-px w-10 bg-brass-500/70 dark:bg-brass-400/60"
              />
              <ul className="mt-5 space-y-2">
                {group.items.map((item) => (
                  <li
                    key={item}
                    className="text-sm leading-relaxed text-ink-700 dark:text-ink-300"
                  >
                    {item}
                  </li>
                ))}
              </ul>
            </Card>
          </Reveal>
        ))}
      </div>
    </Section>
  );
}
