import { Container } from "@/components/ui/Container";
import { metrics, profile } from "@/content/profile";
import {
  ArrowRightIcon,
  DownloadIcon,
  LinkedInIcon,
  PinIcon,
} from "@/lib/icons";

export function Hero() {
  return (
    <section id="top" className="relative overflow-hidden pt-16 pb-16 sm:pt-24 sm:pb-20">
      {/* Restrained backdrop: a faint ledger grid, no gradients competing with the type */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 opacity-[0.55] dark:opacity-[0.35]"
        style={{
          backgroundImage:
            "linear-gradient(to right, rgba(12,22,38,0.045) 1px, transparent 1px), linear-gradient(to bottom, rgba(12,22,38,0.045) 1px, transparent 1px)",
          backgroundSize: "64px 64px",
          maskImage:
            "radial-gradient(ellipse 80% 60% at 50% 0%, black 20%, transparent 75%)",
          WebkitMaskImage:
            "radial-gradient(ellipse 80% 60% at 50% 0%, black 20%, transparent 75%)",
        }}
      />

      <Container className="relative">
        <div className="max-w-3xl animate-fade-up">
          <p className="rule-label">{profile.location}</p>

          <h1 className="mt-6 font-serif text-4xl leading-[1.08] tracking-tight text-ink-900 sm:text-5xl lg:text-[3.75rem] dark:text-paper">
            {profile.name}
          </h1>

          <p className="mt-5 text-lg font-medium text-ink-700 sm:text-xl dark:text-ink-200">
            {profile.role}
          </p>

          <p className="mt-2 text-sm leading-relaxed text-brass-600 sm:text-base dark:text-brass-300">
            ZATCA VAT &amp; Zakat · Statutory &amp; Internal Audit · Company Formation &amp; PRO
            Services
          </p>

          <p className="mt-7 max-w-2xl text-base leading-relaxed text-ink-600 sm:text-lg dark:text-ink-300">
            {profile.positioning}
          </p>

          <div className="mt-9 flex flex-wrap items-center gap-3">
            <a
              href="#work"
              className="group inline-flex items-center gap-2 rounded-full bg-ink-900 px-5 py-3 text-sm font-medium text-paper transition-colors duration-200 hover:bg-ink-700 dark:bg-brass-400 dark:text-ink-950 dark:hover:bg-brass-300"
            >
              View selected work
              <ArrowRightIcon className="h-4 w-4 transition-transform duration-300 ease-subtle group-hover:translate-x-0.5" />
            </a>

            {profile.resumeUrl ? (
              <a
                href={profile.resumeUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 rounded-full border border-ink-900/15 px-5 py-3 text-sm font-medium text-ink-800 transition-colors duration-200 hover:border-ink-900/40 dark:border-ink-100/20 dark:text-ink-100 dark:hover:border-brass-400/60"
              >
                <DownloadIcon className="h-4 w-4" />
                Download CV
              </a>
            ) : null}

            <a
              href={profile.linkedin}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="LinkedIn profile"
              className="inline-flex h-11 w-11 items-center justify-center rounded-full border border-ink-900/15 text-ink-700 transition-colors duration-200 hover:border-brass-400 hover:text-brass-600 dark:border-ink-100/20 dark:text-ink-200 dark:hover:border-brass-400 dark:hover:text-brass-300"
            >
              <LinkedInIcon className="h-[18px] w-[18px]" />
            </a>
          </div>

          <div className="mt-8 flex flex-wrap items-center gap-x-5 gap-y-2 text-xs text-ink-500 dark:text-ink-400">
            <span className="inline-flex items-center gap-1.5">
              <PinIcon className="h-3.5 w-3.5" />
              {profile.location}
            </span>
            {profile.availability.map((item) => (
              <span key={item.label}>
                {item.label}: <span className="text-ink-700 dark:text-ink-200">{item.value}</span>
              </span>
            ))}
          </div>
        </div>

        {/* Headline figures */}
        <dl className="mt-16 grid grid-cols-2 gap-x-6 gap-y-8 border-t border-ink-900/10 pt-10 sm:mt-20 lg:grid-cols-4 dark:border-ink-100/10">
          {metrics.map((metric) => (
            <div key={metric.label}>
              <dt className="sr-only">{metric.label}</dt>
              <dd>
                <span className="font-serif text-3xl text-ink-900 sm:text-4xl dark:text-paper">
                  {metric.value}
                </span>
                <span className="ml-1.5 text-xs font-medium uppercase tracking-wider text-brass-600 dark:text-brass-300">
                  {metric.unit}
                </span>
                <p className="mt-2 text-sm leading-snug text-ink-600 dark:text-ink-400">
                  {metric.label}
                </p>
              </dd>
            </div>
          ))}
        </dl>
      </Container>
    </section>
  );
}
