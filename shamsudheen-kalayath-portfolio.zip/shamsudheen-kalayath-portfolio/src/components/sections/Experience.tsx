import { Reveal } from "@/components/ui/Reveal";
import { Section } from "@/components/ui/Section";
import { experience } from "@/content/profile";

export function Experience() {
  return (
    <Section
      id="experience"
      label="Experience"
      title="Seven years across Saudi Arabia and India"
      tinted
    >
      <div className="relative">
        {/* timeline spine */}
        <div
          aria-hidden
          className="absolute left-[7px] top-2 bottom-2 w-px bg-ink-900/12 sm:left-[7px] dark:bg-ink-100/12"
        />

        <ol className="space-y-14">
          {experience.map((role, index) => (
            <li key={`${role.company}-${role.period}`} className="relative pl-9">
              <Reveal delay={index * 70}>
                <span
                  aria-hidden
                  className={`absolute left-0 top-1.5 h-[15px] w-[15px] rounded-full border-2 ${
                    role.current
                      ? "border-brass-500 bg-brass-400 dark:border-brass-300 dark:bg-brass-400"
                      : "border-ink-300 bg-paper dark:border-ink-600 dark:bg-ink-950"
                  }`}
                />

                <div className="flex flex-wrap items-baseline justify-between gap-x-6 gap-y-1">
                  <h3 className="font-serif text-xl text-ink-900 sm:text-2xl dark:text-paper">
                    {role.role}
                  </h3>
                  <span
                    className={`text-sm font-medium ${
                      role.current
                        ? "text-brass-600 dark:text-brass-300"
                        : "text-ink-500 dark:text-ink-400"
                    }`}
                  >
                    {role.period}
                  </span>
                </div>

                <p className="mt-1.5 text-sm text-ink-600 dark:text-ink-300">
                  <span className="font-medium text-ink-800 dark:text-ink-100">
                    {role.company}
                  </span>
                  <span className="mx-2 text-ink-300 dark:text-ink-600">·</span>
                  {role.location}
                </p>

                <ul className="mt-5 space-y-2.5">
                  {role.highlights.map((highlight) => (
                    <li
                      key={highlight.slice(0, 48)}
                      className="relative pl-5 text-sm leading-relaxed text-ink-700 dark:text-ink-300"
                    >
                      <span
                        aria-hidden
                        className="absolute left-0 top-[0.55rem] h-1 w-1 rounded-full bg-brass-500/80 dark:bg-brass-400/80"
                      />
                      {highlight}
                    </li>
                  ))}
                </ul>
              </Reveal>
            </li>
          ))}
        </ol>
      </div>
    </Section>
  );
}
