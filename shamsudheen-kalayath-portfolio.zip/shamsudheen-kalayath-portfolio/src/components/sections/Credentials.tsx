import { Card } from "@/components/ui/Card";
import { Reveal } from "@/components/ui/Reveal";
import { Section } from "@/components/ui/Section";
import { Tag } from "@/components/ui/Tag";
import { certifications, education, qualifications } from "@/content/profile";
import { CheckIcon } from "@/lib/icons";

function CredentialList({
  heading,
  items,
}: {
  heading: string;
  items: readonly { title: string; issuer: string; period: string | null }[];
}) {
  return (
    <Card className="h-full p-6 sm:p-7">
      <h3 className="text-xs font-semibold uppercase tracking-[0.18em] text-brass-600 dark:text-brass-300">
        {heading}
      </h3>
      <ul className="mt-6 space-y-6">
        {items.map((item) => (
          <li key={item.title}>
            <p className="font-medium leading-snug text-ink-900 dark:text-paper">
              {item.title}
            </p>
            <p className="mt-1 text-sm text-ink-600 dark:text-ink-400">
              {item.issuer}
              {item.period ? (
                <>
                  <span className="mx-2 text-ink-300 dark:text-ink-600">·</span>
                  {item.period}
                </>
              ) : null}
            </p>
          </li>
        ))}
      </ul>
    </Card>
  );
}

export function Credentials() {
  return (
    <Section
      id="credentials"
      label="Credentials"
      title="Qualifications, education and certifications"
      tinted
    >
      <div className="grid gap-6 lg:grid-cols-3">
        <Reveal>
          <CredentialList heading="Professional qualifications" items={qualifications} />
        </Reveal>

        <Reveal delay={90}>
          <CredentialList heading="Education" items={education} />
        </Reveal>

        <Reveal delay={180}>
          <Card className="h-full p-6 sm:p-7">
            <h3 className="text-xs font-semibold uppercase tracking-[0.18em] text-brass-600 dark:text-brass-300">
              Certifications
            </h3>
            <ul className="mt-6 flex flex-wrap gap-2">
              {certifications.map((certification) => (
                <li key={certification}>
                  <Tag>{certification}</Tag>
                </li>
              ))}
            </ul>
            <p className="mt-6 inline-flex items-center gap-2 text-xs text-ink-500 dark:text-ink-400">
              <CheckIcon className="h-3.5 w-3.5 text-brass-500 dark:text-brass-300" />
              Systems certified across SAP, Tally and cloud accounting platforms
            </p>
          </Card>
        </Reveal>
      </div>
    </Section>
  );
}
