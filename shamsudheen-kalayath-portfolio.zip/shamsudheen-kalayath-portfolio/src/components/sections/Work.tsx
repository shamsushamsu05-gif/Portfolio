import { Card } from "@/components/ui/Card";
import { Reveal } from "@/components/ui/Reveal";
import { Section } from "@/components/ui/Section";
import { Tag } from "@/components/ui/Tag";
import { engagements } from "@/content/profile";

const fields = [
  { key: "problem", label: "The situation" },
  { key: "approach", label: "Approach" },
  { key: "contribution", label: "My contribution" },
] as const;

export function Work() {
  return (
    <Section
      id="work"
      label="Selected Work"
      title="Four engagements that define the work"
      intro="Each one is a live, ongoing mandate at Beacon Management Consultants rather than a finished project — the scope, the role and the result as they stand today."
    >
      <div className="grid gap-6 lg:grid-cols-2">
        {engagements.map((engagement, index) => (
          <Reveal key={engagement.id} delay={index * 90}>
            <Card interactive className="flex h-full flex-col p-7 sm:p-8">
              <div className="flex items-start justify-between gap-4">
                <span className="text-xs font-semibold uppercase tracking-[0.16em] text-brass-600 dark:text-brass-300">
                  {engagement.tag}
                </span>
                <span className="shrink-0 text-xs text-ink-500 dark:text-ink-400">
                  {engagement.period}
                </span>
              </div>

              <h3 className="mt-4 font-serif text-xl leading-snug text-ink-900 sm:text-2xl dark:text-paper">
                {engagement.title}
              </h3>
              <p className="mt-1.5 text-sm text-ink-500 dark:text-ink-400">
                {engagement.org}
              </p>

              <dl className="mt-6 space-y-4 border-t border-ink-900/8 pt-6 dark:border-ink-100/10">
                {fields.map((field) => (
                  <div key={field.key}>
                    <dt className="text-[0.7rem] font-semibold uppercase tracking-[0.14em] text-ink-400 dark:text-ink-500">
                      {field.label}
                    </dt>
                    <dd className="mt-1.5 text-sm leading-relaxed text-ink-700 dark:text-ink-300">
                      {engagement[field.key]}
                    </dd>
                  </div>
                ))}
              </dl>

              <div className="mt-6 rounded-lg bg-ink-900/[0.04] p-4 dark:bg-brass-400/[0.07]">
                <p className="text-[0.7rem] font-semibold uppercase tracking-[0.14em] text-ink-500 dark:text-brass-300">
                  Outcome
                </p>
                <p className="mt-1.5 text-sm font-medium leading-relaxed text-ink-900 dark:text-paper">
                  {engagement.outcome}
                </p>
              </div>

              <div className="mt-6 flex flex-wrap gap-2 pt-1">
                {engagement.skills.map((skill) => (
                  <Tag key={skill}>{skill}</Tag>
                ))}
              </div>
            </Card>
          </Reveal>
        ))}
      </div>
    </Section>
  );
}
