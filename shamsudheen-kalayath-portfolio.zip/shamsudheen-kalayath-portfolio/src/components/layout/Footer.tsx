import { Container } from "@/components/ui/Container";
import { profile } from "@/content/profile";

export function Footer() {
  return (
    <footer className="border-t border-ink-900/8 py-10 dark:border-ink-100/10">
      <Container>
        <div className="flex flex-col items-start justify-between gap-4 text-sm text-ink-500 sm:flex-row sm:items-center dark:text-ink-400">
          <p>
            © {new Date().getFullYear()} {profile.name}. {profile.location}.
          </p>
          <div className="flex items-center gap-5">
            <a
              href={`mailto:${profile.email}`}
              className="link-underline hover:text-ink-900 dark:hover:text-paper"
            >
              Email
            </a>
            <a
              href={profile.linkedin}
              target="_blank"
              rel="noopener noreferrer"
              className="link-underline hover:text-ink-900 dark:hover:text-paper"
            >
              LinkedIn
            </a>
            <a href="#top" className="link-underline hover:text-ink-900 dark:hover:text-paper">
              Back to top
            </a>
          </div>
        </div>
      </Container>
    </footer>
  );
}
