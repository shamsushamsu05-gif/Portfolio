"use client";

import { useEffect, useState } from "react";
import { Container } from "@/components/ui/Container";
import { ThemeToggle } from "./ThemeToggle";
import { useActiveSection } from "@/hooks/useActiveSection";
import { navItems, profile } from "@/content/profile";
import { CloseIcon, MenuIcon } from "@/lib/icons";

const hrefs = navItems.map((item) => item.href);

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const active = useActiveSection(hrefs);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = menuOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [menuOpen]);

  return (
    <header
      className={`sticky top-0 z-50 transition-[background-color,border-color,backdrop-filter] duration-300 ${
        scrolled || menuOpen
          ? "border-b border-ink-900/8 bg-paper/85 backdrop-blur-md dark:border-ink-100/10 dark:bg-ink-950/85"
          : "border-b border-transparent"
      }`}
    >
      <Container>
        <div className="flex h-16 items-center justify-between gap-6">
          <a
            href="#top"
            className="font-serif text-lg tracking-tight text-ink-900 dark:text-paper"
          >
            {profile.name.split(" ")[0]}{" "}
            <span className="text-brass-600 dark:text-brass-300">
              {profile.name.split(" ")[1]}
            </span>
          </a>

          <nav className="hidden items-center gap-7 lg:flex" aria-label="Sections">
            {navItems.map((item) => (
              <a
                key={item.href}
                href={item.href}
                className={`text-sm transition-colors duration-200 ${
                  active === item.href
                    ? "text-brass-600 dark:text-brass-300"
                    : "text-ink-600 hover:text-ink-900 dark:text-ink-300 dark:hover:text-paper"
                }`}
              >
                {item.label}
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-2.5">
            <ThemeToggle />
            <a
              href={`mailto:${profile.email}`}
              className="hidden rounded-full bg-ink-900 px-4 py-2 text-sm font-medium text-paper transition-colors duration-200 hover:bg-ink-700 sm:inline-block dark:bg-brass-400 dark:text-ink-950 dark:hover:bg-brass-300"
            >
              Get in touch
            </a>
            <button
              type="button"
              onClick={() => setMenuOpen((open) => !open)}
              aria-label={menuOpen ? "Close menu" : "Open menu"}
              aria-expanded={menuOpen}
              className="inline-flex h-9 w-9 items-center justify-center rounded-full border border-ink-900/12 text-ink-700 lg:hidden dark:border-ink-100/15 dark:text-ink-200"
            >
              {menuOpen ? (
                <CloseIcon className="h-[18px] w-[18px]" />
              ) : (
                <MenuIcon className="h-[18px] w-[18px]" />
              )}
            </button>
          </div>
        </div>
      </Container>

      {menuOpen ? (
        <div className="border-t border-ink-900/8 bg-paper lg:hidden dark:border-ink-100/10 dark:bg-ink-950">
          <Container>
            <nav className="flex flex-col py-3" aria-label="Sections">
              {navItems.map((item) => (
                <a
                  key={item.href}
                  href={item.href}
                  onClick={() => setMenuOpen(false)}
                  className="border-b border-ink-900/6 py-3.5 text-base text-ink-700 last:border-0 dark:border-ink-100/8 dark:text-ink-200"
                >
                  {item.label}
                </a>
              ))}
              <a
                href={`mailto:${profile.email}`}
                onClick={() => setMenuOpen(false)}
                className="mt-4 mb-2 rounded-full bg-ink-900 px-4 py-3 text-center text-sm font-medium text-paper dark:bg-brass-400 dark:text-ink-950"
              >
                Get in touch
              </a>
            </nav>
          </Container>
        </div>
      ) : null}
    </header>
  );
}
