import type { ReactNode } from "react";
import { Container } from "./Container";
import { Reveal } from "./Reveal";

export function Section({
  id,
  label,
  title,
  intro,
  children,
  tinted = false,
}: {
  id: string;
  label: string;
  title: string;
  intro?: string;
  children: ReactNode;
  tinted?: boolean;
}) {
  return (
    <section
      id={id}
      className={`scroll-mt-24 border-t border-ink-900/8 py-20 sm:py-28 dark:border-ink-100/10 ${
        tinted ? "bg-paper-tint dark:bg-ink-900/40" : ""
      }`}
    >
      <Container>
        <Reveal>
          <div className="max-w-2xl">
            <p className="rule-label">{label}</p>
            <h2 className="mt-5 font-serif text-3xl leading-tight tracking-tight text-ink-900 sm:text-4xl dark:text-paper">
              {title}
            </h2>
            {intro ? (
              <p className="mt-4 text-base leading-relaxed text-ink-600 dark:text-ink-300">
                {intro}
              </p>
            ) : null}
          </div>
        </Reveal>
        <div className="mt-12 sm:mt-14">{children}</div>
      </Container>
    </section>
  );
}
