export function Tag({ children }: { children: string }) {
  return (
    <span className="inline-flex items-center rounded-full border border-ink-900/10 bg-paper px-3 py-1 text-xs font-medium text-ink-600 transition-colors duration-200 dark:border-ink-100/12 dark:bg-ink-900/60 dark:text-ink-300">
      {children}
    </span>
  );
}
