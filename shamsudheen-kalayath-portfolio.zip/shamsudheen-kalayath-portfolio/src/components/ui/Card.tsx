import type { ReactNode } from "react";

export function Card({
  children,
  className = "",
  interactive = false,
}: {
  children: ReactNode;
  className?: string;
  interactive?: boolean;
}) {
  return (
    <div
      className={`rounded-xl border border-ink-900/10 bg-white/80 shadow-card backdrop-blur-sm transition-[box-shadow,transform,border-color] duration-300 ease-subtle dark:border-ink-100/10 dark:bg-ink-900/50 ${
        interactive
          ? "hover:-translate-y-0.5 hover:border-brass-400/50 hover:shadow-card-hover"
          : ""
      } ${className}`}
    >
      {children}
    </div>
  );
}
