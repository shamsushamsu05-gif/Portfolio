"use client";

import { useEffect, useState } from "react";

/**
 * Tracks which section is currently in view so the header can highlight it.
 * Takes anchor hrefs ("#about") and returns the active one.
 */
export function useActiveSection(hrefs: readonly string[]) {
  const [active, setActive] = useState<string>(hrefs[0] ?? "");

  useEffect(() => {
    if (typeof IntersectionObserver === "undefined") return;

    const sections = hrefs
      .map((href) => document.getElementById(href.replace("#", "")))
      .filter((el): el is HTMLElement => el !== null);

    if (sections.length === 0) return;

    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((entry) => entry.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];

        if (visible) setActive(`#${visible.target.id}`);
      },
      { rootMargin: "-45% 0px -50% 0px", threshold: [0, 0.2, 0.5] },
    );

    sections.forEach((section) => observer.observe(section));
    return () => observer.disconnect();
  }, [hrefs]);

  return active;
}
