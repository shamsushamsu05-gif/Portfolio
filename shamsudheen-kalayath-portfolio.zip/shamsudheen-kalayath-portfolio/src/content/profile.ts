/**
 * Single source of truth for every piece of content on the site.
 * Edit this file to update the portfolio — no component changes needed.
 *
 * All content is drawn from the candidate's CV and LinkedIn profile.
 * Do not add figures or achievements that are not in those documents.
 */

export const profile = {
  name: "Shamsudheen Kalayath",
  shortName: "Shamsudheen",
  role: "Finance, Audit & Business Advisory Manager",
  headline:
    "Finance, Audit & Business Advisory · ZATCA VAT & Zakat · Company Formation & PRO Services — KSA",
  positioning:
    "I help businesses in Saudi Arabia get set up, stay compliant, and keep their books audit-ready — from commercial registration through to filed, audited accounts.",
  location: "Jizan, Saudi Arabia",
  email: "shamsu.shamsu05@gmail.com",
  phone: "+966 55 644 7124",
  phoneHref: "+966556447124",
  linkedin: "https://www.linkedin.com/in/shamsudheenkalayath",
  linkedinLabel: "linkedin.com/in/shamsudheenkalayath",
  /**
   * Drop a PDF at /public/resume/shamsudheen-kalayath-cv.pdf to enable the
   * download button, or set this to null to hide it.
   */
  resumeUrl: "/resume/shamsudheen-kalayath-cv.pdf",
  availability: [
    { label: "Iqama status", value: "Transferable" },
    { label: "Saudi driving licence", value: "Valid" },
    { label: "Nationality", value: "Indian" },
  ],
} as const;

/** Headline figures — every number here appears verbatim in the source documents. */
export const metrics = [
  { value: "7+", unit: "yrs", label: "Experience across KSA & India" },
  { value: "20+", unit: "entities", label: "Accounts prepared & audited a year" },
  { value: "25+", unit: "clients", label: "VAT filings managed under ZATCA" },
  { value: "10", unit: "people", label: "Back-office team led" },
] as const;

export const about = {
  paragraphs: [
    "Finance and business advisory professional with over seven years across Saudi Arabia and India. I currently lead the Jizan branch of a KSA management consultancy and a back-office team of ten spanning audit, bookkeeping and accounts, while running Bahrain back-office functions alongside it.",
    "Day to day that means accounts preparation and audit for 20+ client entities a year — clients with turnover up to SAR 100M across manufacturing, trading and services — monthly and quarterly VAT filing for 25+ clients under ZATCA, and direct representation when ZATCA opens an audit or assessment.",
    "Before Saudi Arabia I spent three years in audit and accounting practice in India, covering GST, income tax, statutory audit, and rebuilding accounts from incomplete records. Combining statutory and internal audit with tax compliance and hands-on PRO and GRO delivery lets me give clients one point of accountability from company formation through to filed accounts.",
  ],
  pursuing: "Currently pursuing CA and CMA (USA).",
} as const;

/**
 * Featured engagements. Framed as case studies, but each field is grounded in
 * responsibilities and outcomes stated in the CV / LinkedIn profile.
 */
export const engagements = [
  {
    id: "jizan-branch",
    title: "Jizan branch build-out and P&L ownership",
    org: "Beacon Management Consultants",
    period: "Oct 2022 – Present",
    tag: "Operations & Leadership",
    problem:
      "The firm needed a working presence in Jizan: no back office, no local client base and no delivery process in place.",
    approach:
      "Established the back office, built the client base and set up the delivery processes the branch runs on. Took on the Bahrain back-office functions in parallel, and step in to support other branches during staff absences so operations stay uninterrupted.",
    contribution:
      "Own the branch end to end and lead a 10-member back-office team across audit, bookkeeping and accounts, covering the firm's full client portfolio.",
    outcome:
      "Branch taken from launch to a recurring monthly profit of SAR 25,000–50,000.",
    skills: [
      "Branch setup",
      "P&L ownership",
      "Team leadership",
      "Multi-branch operations",
      "Process design",
    ],
  },
  {
    id: "zatca-vat",
    title: "ZATCA VAT compliance and audit representation",
    org: "Beacon Management Consultants",
    period: "Oct 2022 – Present",
    tag: "Tax & Regulatory",
    problem:
      "SME and mid-market clients carry monthly and quarterly VAT obligations under ZATCA, and face real penalty exposure when an audit or assessment is opened.",
    approach:
      "Manage monthly and quarterly VAT filings for 25+ clients in line with ZATCA regulations, calculate and file withholding tax under Saudi tax law, and handle Zakat and corporate compliance alongside it.",
    contribution:
      "Represent clients directly in ZATCA audits and assessments — preparing submissions, responding to queries, and advising clients on their compliance exposure before it becomes an assessment.",
    outcome:
      "Compliance advisory has helped clients avoid fines and penalties running into millions of SAR.",
    skills: [
      "KSA VAT (ZATCA)",
      "Withholding tax",
      "Zakat",
      "Audit representation",
      "Compliance advisory",
    ],
  },
  {
    id: "audit-programme",
    title: "Annual accounts and audit programme, 20+ entities",
    org: "Beacon Management Consultants",
    period: "Oct 2022 – Present",
    tag: "Audit & Reporting",
    problem:
      "A mixed portfolio of manufacturing, trading and services clients — turnover up to SAR 100M — all needing accounts prepared and audited to the same standard each year.",
    approach:
      "Run the preparation and audit cycle for each entity: trial balance and financial statements, bank and intercompany reconciliation, audit file preparation and external auditor coordination, with reporting adapted to each sector.",
    contribution:
      "Prepare and review the work, coordinate internal and statutory audits, and perform the financial analysis and reporting clients use to improve performance and make decisions.",
    outcome:
      "Delivered for 20+ client entities a year, sustained across four consecutive years.",
    skills: [
      "Statutory audit",
      "Internal audit",
      "Financial statements",
      "Reconciliation",
      "Management reporting",
    ],
  },
  {
    id: "incorporation-pro",
    title: "Company formation and government services in KSA",
    org: "Beacon Management Consultants",
    period: "Oct 2022 – Present",
    tag: "Business Advisory",
    problem:
      "Entering the Saudi market means commercial registration, licensing and a continuing stream of government documentation most founders are not equipped to navigate.",
    approach:
      "Advise on company formation, business structuring and regulatory compliance for SMEs and startups, then deliver the PRO and GRO work: licence renewals, government documentation and regulatory liaison.",
    contribution:
      "Executed 10+ client company incorporations in the Kingdom, covering commercial registration, licensing and regulatory setup — then carried the same clients through into bookkeeping, VAT and audit.",
    outcome:
      "Clients get one point of accountability from company formation through to filed accounts.",
    skills: [
      "Company incorporation",
      "Commercial registration",
      "Licensing",
      "PRO & GRO services",
      "Business structuring",
    ],
  },
] as const;

export const experience = [
  {
    company: "Beacon Management Consultants",
    role: "Senior Associate – Finance, Audit & Business Advisory",
    location: "Jizan, Saudi Arabia / Bahrain",
    period: "Oct 2022 – Present",
    current: true,
    highlights: [
      "Built the Jizan branch from launch to a recurring monthly profit of SAR 25,000–50,000, establishing the back office, client base and delivery processes.",
      "Lead a 10-member back-office team across audit, bookkeeping and accounts, covering the firm's full client portfolio.",
      "Prepare and audit accounts for 20+ client entities each year — sustained across four consecutive years — for clients with turnover up to SAR 100M.",
      "Manage monthly and quarterly VAT filings for 25+ clients in compliance with ZATCA regulations.",
      "Represent clients directly in ZATCA audits and assessments, preparing submissions and responding to queries.",
      "Advise clients on compliance exposure, helping them avoid fines and penalties running into millions of SAR.",
      "Executed 10+ client company incorporations in KSA, covering commercial registration, licensing and regulatory setup.",
      "Calculate and file withholding tax (WHT) in accordance with Saudi tax law.",
      "Deliver PRO and GRO services, including licence renewals, government documentation and regulatory liaison.",
      "Run Bahrain back-office functions alongside Jizan, maintaining continuity across both locations.",
      "Coordinate internal and statutory audits: documentation, reconciliations and external auditor liaison.",
    ],
  },
  {
    company: "Okey & Associates Tax Consultant",
    role: "Audit Assistant",
    location: "Manjeri, Kerala, India",
    period: "Nov 2020 – Sep 2022",
    current: false,
    highlights: [
      "Prepared accounts and audit documentation for 5–10 client entities annually.",
      "Prepared and reconciled financial statements to accounting standards and regulatory requirements.",
      "Reconstructed accounts from incomplete records, preserving data integrity and audit trail.",
      "Managed GST and income tax registrations, and filed monthly and annual returns.",
      "Executed internal audits, including voucher verification and invoice vouching.",
      "Conducted bank reconciliations to identify and resolve discrepancies.",
      "Developed projected financial statements to support client strategic planning.",
    ],
  },
  {
    company: "Downtown Café & Bakes LLP",
    role: "Accounts Assistant",
    location: "Ernakulam, Kerala, India",
    period: "Feb 2020 – Nov 2020",
    current: false,
    highlights: [
      "Maintained financial statements and full bookkeeping records.",
      "Ran the billing cycle end to end, from invoice generation through verification.",
      "Managed accounts payable and receivable, improving collection efficiency and cash flow.",
      "Filed monthly and annual GST returns within statutory deadlines.",
      "Processed payroll in line with statutory obligations.",
      "Introduced cost-control protocols to improve operational margin.",
    ],
  },
  {
    company: "Accountants Service Society",
    role: "Accounting Intern",
    location: "Ernakulam, Kerala, India",
    period: "Jul 2019 – Jan 2020",
    current: false,
    highlights: [
      "Built hands-on proficiency in Tally Prime, SAP FICO, SAP MM and SAP B1 across live accounting projects.",
      "Managed month-end close: accruals, repayments, profit and loss statements and balance sheets.",
      "Analysed balance sheets to identify and resolve discrepancies.",
      "Prepared audit files and financial documentation for internal and external audit.",
    ],
  },
] as const;

export const expertise = [
  {
    group: "Finance & Reporting",
    items: [
      "Financial statements (P&L, balance sheet, cash flow)",
      "Accounts reconstruction from incomplete records",
      "Bank & intercompany reconciliation",
      "Month-end and year-end close",
      "Management reporting",
      "GAAP",
      "Budgeting & forecasting",
      "Cost optimisation",
    ],
  },
  {
    group: "Audit & Assurance",
    items: [
      "Statutory audit",
      "Internal audit",
      "Trial balance preparation",
      "Voucher verification & invoice vouching",
      "Audit file preparation",
      "External auditor coordination",
      "ZATCA audit & assessment representation",
    ],
  },
  {
    group: "Tax & Regulatory Compliance",
    items: [
      "KSA VAT (ZATCA)",
      "Withholding tax (WHT)",
      "Zakat",
      "GCC VAT",
      "Indian GST",
      "Income tax & TDS",
      "Corporate governance",
      "Saudi business law",
    ],
  },
  {
    group: "Advisory & Government Services",
    items: [
      "Company incorporation (KSA)",
      "Commercial registration & licensing",
      "PRO & GRO services",
      "Licence renewals",
      "Government documentation",
      "Regulatory liaison",
      "Business structuring for SMEs & startups",
    ],
  },
  {
    group: "Operations & Leadership",
    items: [
      "Branch setup & P&L ownership",
      "Back-office team leadership",
      "Multi-branch operations",
      "Remote branch management",
      "Client portfolio management",
      "Payroll management",
      "Process improvement",
    ],
  },
  {
    group: "Systems & Tools",
    items: [
      "SAP FICO",
      "SAP MM",
      "SAP B1",
      "Tally Prime",
      "QuickBooks",
      "Zoho Books",
      "Sage",
      "Advanced Excel",
      "MS Office Suite",
    ],
  },
] as const;

export const qualifications = [
  {
    title: "Chartered Accountancy (CA)",
    issuer: "In progress",
    period: null,
  },
  {
    title: "Certified Management Accountant (CMA, USA)",
    issuer: "In progress",
    period: null,
  },
  {
    title: "CA IPCC — Accounting and Finance",
    issuer: "The Institute of Chartered Accountants of India (ICAI)",
    period: "2016 – 2019",
  },
] as const;

export const education = [
  {
    title: "Bachelor of Commerce (B.Com)",
    issuer: "University of Madras, Chennai, India",
    period: "2017 – 2020",
  },
  {
    title: "Diploma in Corporate Accounts & Management",
    issuer: "Accountants Service Society, Ernakulam, India",
    period: "2020",
  },
] as const;

export const certifications = [
  "SAP FICO",
  "SAP MM",
  "Tally Prime",
  "QuickBooks",
  "Sage",
  "Advanced Excel",
  "Indian GST",
  "UAE VAT",
  "Professional Accounting Practical Experience",
  "Generally Accepted Accounting Principles (GAAP)",
] as const;

export const languages = [
  { name: "Malayalam", level: "Native" },
  { name: "English", level: "Fluent (IELTS 6.5)" },
  { name: "Hindi", level: "Conversational" },
  { name: "Arabic", level: "Conversational" },
] as const;

export const navItems = [
  { href: "#about", label: "About" },
  { href: "#work", label: "Selected Work" },
  { href: "#experience", label: "Experience" },
  { href: "#expertise", label: "Expertise" },
  { href: "#credentials", label: "Credentials" },
  { href: "#contact", label: "Contact" },
] as const;
